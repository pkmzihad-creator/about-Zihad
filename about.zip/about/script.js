const terminalInput = document.getElementById("terminal-input");
const terminalOutput = document.getElementById("terminal-output");
const passwordModal = document.getElementById("password-modal");
const closeModal = document.getElementById("close-modal");
const submitPassword = document.getElementById("submit-password");
const passwordField = document.getElementById("password-field");

let activeBook = null;

const commands = {
  about: `Professional Summary
------------------------
Multifaceted educator and IT professional with experience in Teaching, Cybersecurity, Office Administration, and Technical Skills Training. Capable of teaching various subjects such as English, Math, ICT, and MS Office programs. Well-versed in Debian-based systems, Graphic Design, and Generative AI tools. Fluent in English with strong presentation and communication skills, committed to enhancing students' learning experiences and technical proficiency.

Key Skills
------------------------
Teaching & Training: Expertise in teaching English, Math, ICT, MS Office programs, computer hardware, and AI tools.
Cybersecurity Expertise: Hands-on experience with ethical hacking, CTF competitions, and Debian-based systems (Kali, Parrot).
Microsoft Office: Skilled in Word, Excel, and PowerPoint.
Graphic Design: Proficient in Adobe Illustrator and Photoshop.
Generative AI Tools: Practical knowledge of AI applications.
Computer Hardware & Software: Skilled in troubleshooting, setup, and technical training.
Communication & Presentation: Strong English speaking and writing abilities.

Work Experience
------------------------
Teacher
Real Multimedia School | Bogura, Bangladesh 		            January 2022 – August 2023
• Taught English, Math, Bangla, Global Studies, and ICT.
• Delivered training in MS Office programs (Word, Excel, PowerPoint) and Generative AI tools.
• Developed curriculum materials to enhance students' learning outcomes.
• Conducted language improvement sessions for English proficiency.
• Provided instruction in subjects like English, Bangla, Math, and Global Studies.
• Participated in updating the school's curriculum to incorporate technical skills.

Cybersecurity Competitor & Ethical Hacking Enthusiast
Various CTF Competitions | BGD e-GOV CIRT, TryHackMe, Cyber Talents etc. September 2021 – Present
• Engaged in ethical hacking using Kali and Parrot OS.
• Solved real-world security challenges during competitions.

Accounting Program – As-Sunnah Skill Development Institute
------------------------
Focused on practical accounting and business skills, including:
• Financial Accounting: Understanding the basics of bookkeeping, journal entries, and ledger management.
• Budgeting and Forecasting: Techniques for preparing budgets and financial forecasts.
• Taxation Principles: Basic concepts of taxation and compliance requirements.
• Accounts Payable/Receivable Management: Handling invoices, payments, and credit control.
• Payroll Accounting: Managing payroll systems and employee salary calculations.
• Financial Statement Analysis: Analyzing balance sheets, income statements, and cash flow statements.
• Accounting Software: Training on software like Tally and QuickBooks for practical application.
• Reconciliation Processes: Bank reconciliation and financial record verification.
• Auditing Basics: Fundamentals of internal and external auditing practices.

IELTS Course
------------------------
(7 months) – Saifur's: Excluded Writing, Spoken
Completed the course but did not take the exam; proficient in English speaking and writing.

Technical Skills
------------------------
Operating Systems: Debian-based (Kali, Parrot), Windows.
Software: MS Office (Word, Excel, PowerPoint), Adobe Photoshop, Adobe Illustrator.
Languages: Bengali (Native), English (Fluent).
  `,

  ebooks: `
Available eBooks:
1. Book 1 (Enter 1 to download)
2. Book 2 (Enter 2 to download)
3. Book 3 (Enter 3 to download)
Password required.`,
  
  contact: `
Contact Information:
Email: zihad.connects@gmail.com
Facebook: https://www.facebook.com/pkmzihad10
Twitter: https://x.com/pkmzihad
LinkedIn: https://www.linkedin.com/in/pkmzihad/
  `,

  help: `
Available Commands:
- about: View details about me
- ebooks: View and download eBooks (requires password)
- contact: Get my contact information
- clear: Clear the terminal
- exit: Exit the terminal interface
- help: Show this help menu
  `,
};

function simulateLoading(callback) {
  let progress = 1;
  const line = document.createElement("div");
  terminalOutput.appendChild(line);

  const interval = setInterval(() => {
    line.textContent = `Loading... ${progress}% ` + ".".repeat(progress % 10);
    if (progress === 100) {
      clearInterval(interval);
      callback();
    } else {
      progress++;
    }
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
  }, 20); // Faster animation
}

function handleCommand(input) {
  const args = input.trim().split(" ");
  const command = args[0];
  const param = args[1];

  if (command === "clear") {
    terminalOutput.innerHTML = "";
  } else if (command === "exit") {
    printOutput("Exiting terminal... Goodbye!");
    setTimeout(() => {
      window.close();
    }, 1000);
  } else if (commands[command]) {
    simulateLoading(() => printOutput(commands[command]));
  } else if (["1", "2", "3"].includes(command)) {
    activeBook = command;
    openModal();
  } else {
    simulateLoading(() => printOutput(`Command not found: ${command}`));
  }
}

function openModal() {
  passwordModal.style.display = "block";
}

function closeModalHandler() {
  passwordModal.style.display = "none";
}

function submitPasswordHandler() {
  const password = passwordField.value;
  if (password === "000x" && activeBook) {
    closeModalHandler();
    window.location.href = `books/book${activeBook}.pdf`;
  } else {
    alert("Incorrect password!");
  }
}

function printOutput(text) {
  const newLine = document.createElement("div");
  newLine.textContent = text;
  terminalOutput.appendChild(newLine);
  terminalOutput.scrollTop = terminalOutput.scrollHeight;
}

terminalInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    const input = terminalInput.value;
    printOutput(`$ ${input}`);
    handleCommand(input);
    terminalInput.value = "";
  }
});

closeModal.addEventListener("click", closeModalHandler);
submitPassword.addEventListener("click", submitPasswordHandler);
